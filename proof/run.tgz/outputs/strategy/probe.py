#!/usr/bin/env python3
"""Bounded, non-production A180206 strategy diagnostics. Never goes beyond n=16."""
import itertools
import json
import math
from pathlib import Path
import resource
import time

ROOT = Path(__file__).resolve().parents[2]


def member(p):
    # Definition-level residue-minimum test; no zero anchoring or subset DP.
    d = [0, 0, 0]
    low = [0, 0, 0]
    for i in range(len(p) - 1):
        r = i % 3
        d[r] += p[i + 1] - p[i]
        low[r] = min(low[r], d[r])
    return -sum(low) <= p[0]


def main():
    start = time.monotonic()
    expected = dict(tuple(map(int, x.split())) for x in
                    (ROOT / 'data/b180206.txt').read_text().splitlines() if x.strip())
    assert list(expected) == list(range(1, 17))
    M = 15
    F = [0] * (1 << M)
    F[0] = 1
    current = {0: {(0, 0): 1}}
    layers = []
    for h in range(1, M + 1):
        t = time.monotonic()
        following = {}
        updates = 0
        for mask, states in current.items():
            choices = ((1 << M) - 1) ^ mask
            while choices:
                bit = choices & -choices
                choices -= bit
                v = bit.bit_length()
                dest = following.setdefault(mask | bit, {})
                for (a, b), weight in states.items():
                    c = v - a - b
                    if c >= 0:
                        key = (b, c)
                        dest[key] = dest.get(key, 0) + weight
                        updates += 1
        for mask, states in following.items():
            labels = [i + 1 for i in range(M) if mask >> i & 1]
            assert states  # increasing ordering always exists
            for (a, b), w in states.items():
                assert a + b <= max(labels)
                assert (2 * a + b - sum(labels)) % 3 == 0
                assert 0 < w <= math.factorial(h)
            F[mask] = sum(states.values())
            assert F[mask] <= math.factorial(h)
        current = following
        layers.append({'h': h, 'subsets': len(current),
                       'nonzero_states': sum(map(len, current.values())),
                       'updates': updates, 'seconds': time.monotonic() - t})
    replay = {}
    for n in range(1, 17):
        full = (1 << (n - 1)) - 1
        got = sum(F[s] * F[full ^ s] for s in range(full + 1))
        assert got == expected[n], (n, got, expected[n])
        replay[n] = got
    direct = {}
    for n in range(1, 9):
        got = sum(member(p) for p in itertools.permutations(range(n)))
        assert got == expected[n]
        direct[n] = got
    # Every order of every small positive-label subset, coefficient by coefficient.
    for mask in range(1 << 7):
        labels = [i + 1 for i in range(7) if mask >> i & 1]
        got = 0
        for word in itertools.permutations(labels):
            a = b = 0
            for v in word:
                a, b = b, v - a - b
                if b < 0:
                    break
            else:
                got += 1
        assert got == F[mask]
    geometry = []
    for n in [16, 17, 24, 25, 26, 27, 28, 29]:
        m = n - 1
        counts = [sum((2*a+b) % 3 == r for a in range(m+1)
                      for b in range(m+1-a)) for r in range(3)]
        K = max(counts)
        width = lambda h: 8 if h <= 20 else 16
        layer_pairs = [K * (math.comb(m, h)*width(h) +
                           math.comb(m, h+1)*width(h+1)) for h in range(m)]
        principal = 16 * (1 << m) + max(layer_pairs)
        all128 = 16 * ((1 << m) + K * max(math.comb(m,h)+math.comb(m,h+1)
                                         for h in range(m)))
        # Simple unfiltered padded pull bound; ranks/zeroing excluded.
        pull = K * m * (1 << (m-1))
        pull_exact = 0
        for v in range(1, m+1):
            residues = [1, 0, 0]
            for u in range(1, m+1):
                if u != v:
                    residues = [residues[r] + residues[(r-u) % 3] for r in range(3)]
            for r in range(3):
                kr = sum((2*a+b) % 3 == r for a in range(v+1)
                         for b in range(v+1-a))
                pull_exact += residues[(r-v) % 3] * kr
        # Full triangular repeated-label pull, both modular channels.
        ie = 2 * m * (1 << (m-1)) * sum(math.comb(v+2,2) for v in range(1,m+1))
        geometry.append({'n': n, 'K_by_residue': counts, 'principal_bytes': principal,
                         'principal_gib': principal / 2**30,
                         'all128_bytes': all128, 'pull_bound': pull,
                         'pull_geometric_reads': pull_exact,
                         'cumulative_table_writes_bytes': 16*(1 << m) + K*sum(
                             math.comb(m,h)*width(h) for h in range(1,m+1)),
                         'ie_two_channel_additions': ie,
                         'answer_bound_bits': math.factorial(n).bit_length(),
                         'ie_loose_bound_bits': ((1 << m)*(m+1)*m**m).bit_length()})
    # Check the residue-distribution read formula by enumerating all small masks.
    for m in range(1, 8):
        brute = 0
        for mask in range(1, 1 << m):
            residue = sum(v for v in range(1,m+1) if mask >> (v-1) & 1) % 3
            for v in range(1,m+1):
                if mask >> (v-1) & 1:
                    brute += sum((2*a+b) % 3 == residue for a in range(v+1)
                                 for b in range(v+1-a))
        predicted = 0
        for v in range(1,m+1):
            residues = [1,0,0]
            for u in range(1,m+1):
                if u != v:
                    residues = [residues[r]+residues[(r-u)%3] for r in range(3)]
            predicted += sum(residues[(r-v)%3] * sum((2*a+b)%3==r
                             for a in range(v+1) for b in range(v+1-a))
                             for r in range(3))
        assert brute == predicted
    out = {'scope': 'NON_PRODUCTION_KNOWN_DATA_ONLY', 'replay': replay,
           'direct_definition_totals': direct, 'all_small_coefficients': 128,
           'layers': layers, 'geometry': geometry,
           'seconds': time.monotonic() - start,
           'peak_rss_bytes_linux': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024}
    Path(__file__).with_name('probe.json').write_text(json.dumps(out, indent=2) + '\n')
    print(json.dumps({k: v for k, v in out.items() if k != 'layers'}, indent=2))


if __name__ == '__main__':
    main()
